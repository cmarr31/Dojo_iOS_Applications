//
//  ViewController.swift
//  swiftFundamentals1
//
//  Created by Chris Marr on 7/25/18.
//  Copyright © 2018 Chris Marr. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        let type: String = "Rectangle"
        let description: String = "A quadrilateral with four right angles"
        var width: Double = 5
        var height = 10.5
        let area = width * height
        height += 1
        width += 1
        //area = width * height
        // Note how you can "interpolate" variables into Strings using the following syntax
        print("The shape is a \(type) or \(description) with an area of \(area)")

    }

}

